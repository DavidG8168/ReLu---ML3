import numpy as np


# ************************************** RELU FUNCTION ****************************************************************
# ReLu.
# x-> Numpy array.
def relu(x):
    return np.maximum(0, x)


# ************************************** THE NET CLASS ****************************************************************
# A network with two layers.
class Net(object):
    # Initialize the class.
    # input_size -> The dimension of the input data.
    # hidden_size -> the amount of neurons in a layer.
    # output_size -> The number of classes.
    def __init__(self, input_size, hidden_size, output_size, std=1e-4):
        # Parameters will be stored here.
        self.params = {}
        # Weights of first layer, initialized to small random values.
        self.params['W1'] = std * np.random.randn(input_size, hidden_size)
        # Bias of first layer.
        self.params['b1'] = np.zeros((1, hidden_size))
        # Weights of second layer, initialized to small random values.
        self.params['W2'] = std * np.random.randn(hidden_size, output_size)
        # Bias of second layer.
        self.params['b2'] = np.zeros((1, output_size))

    # ************************************** LOSS FUNCTION ************************************************************
    # Calculate the loss and gradients.
    # train_data -> Training data sample.
    # train_labels -> Labels.
    def calculate_loss(self, train_data, train_labels=None, regularization_strength=0.0):
        # Get variables from the params dictionary member.
        W1 = self.params['W1']
        b1 = self.params['b1']
        W2 = self.params['W2']
        b2 = self.params['b2']
        N, D = train_data.shape
        # Compute the forward pass.
        h1 = relu(np.dot(train_data, W1) + b1)
        out = np.dot(h1, W2) + b2
        scores = out
        # If the targets are not given then jump out, we're done.
        if train_labels is None:
            return scores
        # Calculate the loss.
        scores_max = np.max(scores, axis=1, keepdims=True)  # (N,1)
        exp_scores = np.exp(scores - scores_max)  # (N,C)
        probs = exp_scores / np.sum(exp_scores, axis=1, keepdims=True)  # (N,C)
        correct_logprobs = -np.log(probs[range(N), train_labels])  # (N,1)
        data_loss = np.sum(correct_logprobs) / N
        reg_loss = 0.5 * regularization_strength * np.sum(W1 * W1) + 0.5 * regularization_strength * np.sum(W2 * W2)
        loss = data_loss + reg_loss
        # Backward pass: compute gradients.
        grads = {}
        dscores = probs
        dscores[range(N), train_labels] -= 1
        dscores /= N
        dW2 = np.dot(h1.T, dscores)
        db2 = np.sum(dscores, axis=0, keepdims=True)
        dh1 = np.dot(dscores, W2.T)
        dh1[h1 <= 0] = 0
        dW1 = np.dot(train_data.T, dh1)
        db1 = np.sum(dh1, axis=0, keepdims=True)
        dW2 += regularization_strength * W2
        dW1 += regularization_strength * W1
        grads['W1'] = dW1
        grads['b1'] = db1
        grads['W2'] = dW2
        grads['b2'] = db2
        return loss, grads

    # ************************************** PREDICTION FUNCTION ******************************************************
    # Classify the data and predict the result.
    # test_x -> Data to classify.
    def predict_result(self, test_x):
        h1 = relu(np.dot(test_x, self.params['W1']) + self.params['b1'])
        scores = np.dot(h1, self.params['W2']) + self.params['b2']
        prediction = np.argmax(scores, axis=1)
        return prediction

    # ************************************** TRAIN FUNCTION ***********************************************************
    # Train the net using gradient descent.
    # train_data -> Training data.
    # train_labels -> Labels.
    # value_x -> Validation data.
    # value_y -> Validation labels.
    # learning_rate -> The learning rate for optimization.
    # learning_rate_decay -> By how much to lower the learning rate after each epoch.
    # regularization_strength -> Regularization strength.
    # epochs -> The amount of epochs for training,
    # sample_size -> Amount of samples used in each epoch.
    def train_net(self, train_data, train_labels, value_x, value_y, learning_rate=1e-3, learning_rate_decay=0.95,
                  regularization_strength=1e-5, mu=0.9, epochs=10, mu_increase=1.0, sample_size=200, verbose=False):
        num_train = train_data.shape[0]
        iterations_per_epoch = max(int(num_train / sample_size), 1)
        # Use SGD to optimize the parameters.
        v_W1 = 0.0
        v_b1 = 0.0
        v_W2 = 0.0
        v_b2 = 0.0
        for it in range(1, epochs * iterations_per_epoch + 1):
            # Create a random mini-batch containing training data and labels.
            sample_index = np.random.choice(num_train, sample_size, replace=True)
            batch_x = train_data[sample_index, :]
            batch_y = train_labels[sample_index]
            # Calculate the loss and gradients using the above mini-batch.
            loss, grads = self.calculate_loss(batch_x, train_labels=batch_y,
                                              regularization_strength=regularization_strength)
            # Use the gradients to update the network.
            v_W2 = mu * v_W2 - learning_rate * grads['W2']
            self.params['W2'] += v_W2
            v_b2 = mu * v_b2 - learning_rate * grads['b2']
            self.params['b2'] += v_b2
            v_W1 = mu * v_W1 - learning_rate * grads['W1']
            self.params['W1'] += v_W1
            v_b1 = mu * v_b1 - learning_rate * grads['b1']
            self.params['b1'] += v_b1
            # Every epoch, check the training and value accuracy, and then decay the learning rate.
            if verbose and it % iterations_per_epoch == 0:
                # Decay the learning rate.
                learning_rate *= learning_rate_decay
                mu *= mu_increase


# ************************************** THE MAIN CLASS ***************************************************************
def main():
    # ********************************** PRE-PROCESSING ***************************************************************
    # Get data from the files.
    # Training sets.
    train_x = np.loadtxt("train_x")
    train_y = np.loadtxt("train_y")
    # Testing sets.
    test_x = np.loadtxt("test_x")
    # Convert them to integers.
    train_x = train_x.astype(int)
    train_y = train_y.astype(int)
    test_x = test_x.astype(int)
    m_train = train_x.shape[0]
    # ********************************** SUBSAMPLE THE DATA ***********************************************************
    np.random.seed(0)
    list(np.random.randint(m_train, size=9))
    # Subsample the data
    m_test = test_x.shape[0]
    m_train = 54000
    validation_set = 1000
    mask = list(range(m_train, m_train + validation_set))
    value_x = train_x[mask]
    value_y = train_y[mask]
    mask = list(range(m_train))
    train_x = train_x[mask]
    train_y = train_y[mask]
    mask = list(range(m_test))
    test_x = test_x[mask]
    # ********************************** RESHAPE DATA *****************************************************************
    # Reshape data to rows
    train_x = train_x.reshape(m_train, -1)
    value_x = value_x.reshape(validation_set, -1)
    test_x = test_x.reshape(m_test, -1)
    # ********************************** TRAIN ************************************************************************
    input_size = train_x.shape[1]
    # Create a new with 10 classes and 10 neurons.
    two_layer_net = Net(input_size, 10, 10)
    # Train the network
    two_layer_net.train_net(train_x, train_y, value_x, value_y, epochs=10, sample_size=1024, learning_rate=7.5e-4,
                            learning_rate_decay=0.95, regularization_strength=1.0, verbose=True)
    # ********************************** TEST *************************************************************************
    # Open a file for writing.
    f = open("test_y", "w")
    # Iterate all the testing set.
    for i in range(0, 5000):
        # Get the prediction.
        x = two_layer_net.predict_result(test_x[i])[0]
        # Don't print a newline on the last row.
        if i == 4999:
            x_str = str(x)
        else:
            x_str = str(x) + "\n"
        # Write the result to the file.
        f.write(x_str)
    # *****************************************************************************************************************


if __name__ == "__main__":
    main()
